ALTER TABLE `projectContent` ADD `scriptComplianceScore` int;--> statement-breakpoint
ALTER TABLE `projectContent` ADD `visualComplianceScore` int;--> statement-breakpoint
ALTER TABLE `projectContent` ADD `storyboardComplianceScore` int;--> statement-breakpoint
ALTER TABLE `projectContent` ADD `voiceoverComplianceScore` int;--> statement-breakpoint
ALTER TABLE `projectContent` ADD `complianceMetadata` text;