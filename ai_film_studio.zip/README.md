# ai_film_studio
A Django-based AI Film Studio application converted from a Streamlit implementation. It includes project management, script generation, visual style definition, technical script creation, and storyboard generation. · Built with Manus
